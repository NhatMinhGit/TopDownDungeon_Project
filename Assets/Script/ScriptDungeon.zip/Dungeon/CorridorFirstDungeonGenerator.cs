﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class CorridorFirstDungeonGenerator : SimpleRandomWalkDungeonGenerator // lớp này kế thừa từ lớp SimpleRandomWalkDungeonGenerator
{
    [SerializeField]
    private int corridorLength = 14 , corridorCount = 5;
    
    [SerializeField]
    [Range(0.1f,1)]
    private float roomPercent = 0.8f;


    private void Start()
    {
        RunProceduralGeneration();
        
    }

    protected override void RunProceduralGeneration()
    {
        //tilemapVisualizer.Clear();
        CorridorFirstGeneration();
    }

    private void CorridorFirstGeneration()
    {
        HashSet<Vector2> floorPositions = new HashSet<Vector2>(); //khai báo danh sách các vị trí của floorPositions 
        HashSet<Vector2> potentialRoomPositions = new HashSet<Vector2>();


        CreateCorridors(floorPositions, potentialRoomPositions);//gọi hàm tạo corridor

        HashSet<Vector2> roomPositions = CreateRooms(potentialRoomPositions);
        List<Vector2> deadEnds = FindAllDeadEnds(floorPositions);

        CreateRoomsAtDeadEnd(deadEnds,roomPositions);

        floorPositions.UnionWith(roomPositions);

        tilemapVisualizer.PaintFloorTiles(floorPositions); // vẽ vị trí floorPositions đã gồm corridor
        WallGenerator.CreateWalls(floorPositions, tilemapVisualizer); //gọi hàm tạo tường để hoàn thành việc tạo 1 hành lang 
    }

    private void CreateRoomsAtDeadEnd(List<Vector2> deadEnds, HashSet<Vector2> roomFloors)
    {
        foreach(var position in deadEnds)
        {
            if(roomFloors.Contains(position) == false)
            {
                var room = RunRandomWalk(randomWalkParameters,position);
                roomFloors.UnionWith(room);
            }
        }
    }

    private List<Vector2> FindAllDeadEnds(HashSet<Vector2> floorPositions)
    {
        List<Vector2> deadEnds = new List<Vector2>();
        foreach(var position in floorPositions)
        {
            int neighboursCount = 0;
            foreach(var direction in Direction2D.directionList)
            {
                if (floorPositions.Contains(position + direction))
                    neighboursCount++;
            }
            if (neighboursCount == 1)
                deadEnds.Add(position);
        }
        return deadEnds;
    }

    private HashSet<Vector2> CreateRooms(HashSet<Vector2> potentialRoomPositions)
    {
        HashSet<Vector2> roomPositions = new HashSet<Vector2>();
        int roomToCreateCount = Mathf.RoundToInt(potentialRoomPositions.Count * roomPercent);

        List<Vector2> roomsToCreate = potentialRoomPositions.OrderBy(x => Guid.NewGuid()).Take(roomToCreateCount).ToList();

        foreach(var roomPosition in roomsToCreate)
        {
            var roomFloor = RunRandomWalk(randomWalkParameters, roomPosition);
            roomPositions.UnionWith(roomFloor);
        }
        return roomPositions;
    }

    public void CreateCorridors(HashSet<Vector2> floorPositions , HashSet<Vector2> potentialRoomPositions)
    {
        var currentPosition = startPosition;
        potentialRoomPositions.Add(currentPosition);//tạo 1 phòng cho chỗ mình bắt đầu

        for(int i = 0; i < corridorCount; i++)
        {
            var corridor = ProceduralGenerationAlgorithms.RandomWalkCorridor(currentPosition,corridorLength+5);// khai biến corridor và gán với giá trị được tạo bỏi hàm RandomWalkCorridor dựa trên (vị trí hiện tại,độ dài của hành lang) 
            currentPosition = corridor[corridor.Count - 1]; // sau đó gán vị trí hiện tại = vị trí corridor[n-1] (vì [] bắt đầu từ 0)
            potentialRoomPositions.Add(currentPosition);//tạo 1 phòng cho mỗi cuối hành lang
            floorPositions.UnionWith(corridor); // Hợp giá trị của corridor vào với floorPositions 
        }
    }
}

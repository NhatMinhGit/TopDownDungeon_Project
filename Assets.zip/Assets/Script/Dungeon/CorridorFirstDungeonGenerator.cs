﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Random = System.Random;

public class CorridorFirstDungeonGenerator : SimpleRandomWalkDungeonGenerator // lớp này kế thừa từ lớp SimpleRandomWalkDungeonGenerator
{
    [SerializeField]
    private int corridorLength = 14 , corridorCount = 5;
    
    [SerializeField]
    [Range(0.1f,1)]
    private float roomPercent = 0.8f;

 
    
   


    [SerializeField]
    public GameObject prefab;//khai báo prefab

        [Range(0f, 1f)]
        public float spawnChance;//Tỉ lệ spawn
    
    

    private void Start()
    {
        tilemapVisualizer.Clear();
        RunProceduralGeneration();

    }
    
    protected override void RunProceduralGeneration()
    {
        CorridorFirstGeneration();
    }



    private void CorridorFirstGeneration()
    {
        HashSet<Vector2> floorPositions = new HashSet<Vector2>(); //khai báo danh sách các vị trí của floorPositions 
        HashSet<Vector2> wallPositions = new HashSet<Vector2>();
        HashSet<Vector2> potentialRoomPositions = new HashSet<Vector2>();
       

        CreateCorridors(floorPositions, potentialRoomPositions);//gọi hàm tạo corridor

        HashSet<Vector2> roomPositions = CreateRooms(potentialRoomPositions);
        HashSet<Vector2> deadEnds = FindAllDeadEnds(floorPositions);

        CreateRoomsAtDeadEnd(deadEnds,roomPositions);

        floorPositions.UnionWith(roomPositions);


        tilemapVisualizer.PaintFloorTiles(floorPositions); // vẽ vị trí floorPositions đã gồm corridor
        WallGenerator.CreateWalls(floorPositions, tilemapVisualizer); //gọi hàm tạo tường để hoàn thành việc tạo 1 hành lang 
       
    }
    
    private void CreateRoomsAtDeadEnd(HashSet<Vector2> deadEnds, HashSet<Vector2> roomFloors)
    {
        foreach(var position in deadEnds)
        {
            if(roomFloors.Contains(position) == false)//!!! lưu ý
            {
                var room = RunRandomWalk(randomWalkParameters,position);
                roomFloors.UnionWith(room);
            }
        }
    }
    
    private void Spawn(GameObject enemy ,HashSet<Vector2> floorPositions)
    {
        foreach(var position in floorPositions)
        {
            Instantiate(enemy);


        }
    }
    

    

    private HashSet<Vector2> FindAllDeadEnds(HashSet<Vector2> floorPositions)
    {
        HashSet<Vector2> deadEnds = new HashSet<Vector2>();
        foreach(var position in floorPositions)
        {
            int neighboursCount = 0;
            foreach(var direction in Direction2D.directionList)
            {
                if (floorPositions.Contains(position + direction))
                    neighboursCount++;
            }
            if (neighboursCount == 1)
                deadEnds.Add(position);
        }
        return deadEnds;
    }

    private HashSet<Vector2> CreateRooms(HashSet<Vector2> potentialRoomPositions)
    {
        HashSet<Vector2> roomPositions = new HashSet<Vector2>();
        int roomToCreateCount = Mathf.RoundToInt(potentialRoomPositions.Count * roomPercent);

        List<Vector2> roomsToCreate = potentialRoomPositions.OrderBy(x => Guid.NewGuid()).Take(roomToCreateCount).ToList();
      
        foreach(var roomPosition in roomsToCreate)
        {
            var roomFloor = RunRandomWalk(randomWalkParameters, roomPosition);
        }
        return roomPositions;
    }
    
    private void CreateCorridors(HashSet<Vector2> floorPositions, HashSet<Vector2> potentialRoomPositions)
    {
        var currentPosition = startPosition;
        potentialRoomPositions.Add(currentPosition);

        for (int i = 0; i < corridorCount; i++)
        {
            var corridor = ProceduralGenerationAlgorithms.RandomWalkCorridor(currentPosition, corridorLength);
            currentPosition = corridor[corridor.Count - 1];
            potentialRoomPositions.Add(currentPosition);
            floorPositions.UnionWith(corridor);
        }
    }

}

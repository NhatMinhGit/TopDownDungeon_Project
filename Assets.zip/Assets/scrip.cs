using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class scrip : MonoBehaviour
{
    [SerializeField] float speed;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 pos = transform.position;
        if (Input.GetKey(KeyCode.A))
        {
            pos.x -= speed * Time.deltaTime;
            Debug.Log("A press ");
        }
        if (Input.GetKey(KeyCode.D))
        {
            pos.x += speed * Time.deltaTime;
            Debug.Log("D press ");
        }
        if (Input.GetKey(KeyCode.W))
        {
            pos.y += speed * Time.deltaTime;
            Debug.Log("W press ");
        }
        if (Input.GetKey(KeyCode.S))
        {
            pos.y -= speed * Time.deltaTime;
            Debug.Log("S press ");
        }
        transform.position = pos;
    }
}
